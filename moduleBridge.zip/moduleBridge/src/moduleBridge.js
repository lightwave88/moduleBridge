const reg_1 = /^\[object Object\]$/;

const proto_toString = Object.prototype.toString;
const class2type = {};
const class2typeCts = {}.constructor;
const hasOwn = class2type.hasOwnProperty;
////////////////////////////////////////
let $UID = 0;

// 用來串聯各個 module
class ModuleBridge {
  $id;
  $parent;
  $childs = new Set();

  // 自己區塊的模組
  $modules = {};

  // 對外 export handle
  $exportList = {};
  $exportFun;

  $onloadList = [];
  //--------------------------------------
  constructor() {
    // debugger;
    this.$id = $UID++;
  }
  //--------------------------------------
  get parent() {
    return this.$parent;
  }
  //--------------------------------------
  set parent(value) {
    if (this.$parent != null) {
      throw new Error('has parent before');
    }
    this.$parent = value;
  }
  //--------------------------------------
  // 知道有那些 modules
  modules(justSelf = false) {
    let $m = {};
    let root = this;

    while (root != null) {
      Object.assign($m, root.$modules);
      if (justSelf === true) {
        break;
      }
      root = root.$parent || null;
    }
    return $m;
  }
  //--------------------------------------
  // API
  // ({})
  // (name, module)
  import(name, module = null) {
    // debugger;

    if (module == null) {
      if (isPlainObject(name)) {
        let modules = name;
        name = null;
        for (let moduleName in modules) {
          this.import(moduleName, modules[moduleName]);
        }
      }
    } else {
      if (name in this.$modules) {
        throw new Error(`name(${name}) conflict`);
      }
      this.$modules[name] = module;
    }
  }
  //--------------------------------------
  // (name, handle)
  // ([name...], handle)
  // ({name:name_1}, handle)
  importHandle(name, handle = null) {
    // debugger;

    if (handle == null) {
      handle = name;
      name = null;
    }
    if (typeof(handle) != 'function') {
      throw new TypeError('...');
    }
    let res = handle.call(this, this);

    if (name == null) {
      return res;
    }
    let modules = $organizeSettings(name, res);
    this.import(modules);

    return res;
  }
  //--------------------------------------
  // API
  // 是否要往上層找
  get(name) {
    let res = null;

    let $this = this;
    while ($this != null) {
      if (name in $this.$modules) {
        res = $this.$modules[name];
        break;
      }
      $this = $this.$parent;
    }
    if (res == null) {
      throw new Error(`no this module(${name})`);
    }

    return res;
  }
  //--------------------------------------
  // API
  has(name, justSelf = false) {
    let $this = this;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    while ($this != null) {
      if (name in $this.$modules) {
        return true;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return false;
  }
  //--------------------------------------
  // 對外輸出
  // (callback)
  // ([...])
  // ('*') 匯出所有
  export (arg) {
    // debugger;
    if (typeof(arg) == 'function') {
      this.$exportFun = arg.bind(this, this);
    } else if (Array.isArray(arg)) {
      this.$exportList = arg;
    } else if (typeof(arg) == 'string' && arg == '*') {
      this.$exportFun = () => {
        // debugger;
        return this.modules;
      };
    } else {
      throw new TypeError('...');
    }
  }
  //--------------------------------------
  // 傳統用法
  linkParent(parent) {
    // debugger;
    if (!(parent instanceof ModuleBridge)) {
      throw new Error('.....');
    }
    child.parent = parent;
    parent.$childs.add(child);
  }
  //--------------------------------------
  // ({}, module)
  // ([], module)
  // (module)
  importModule(importSettings, child) {
    // debugger;
    if (arguments.length == 1) {
      child = importSettings;
      importSettings = null;
    }

    if (!(child instanceof ModuleBridge)) {
      throw new Error('.....');
    }

    if (importSettings != null) {
      (() => {
        if (typeof(importSettings) == 'string') {
          return true;
        }
        if (isPlainObject(importSettings)) {
          return true;
        }
        if (Array.isArray(importSettings)) {
          return true;
        }
        throw new Error('...');
      })();
    }
    //-------------
    child.parent = this;
    this.$childs.add(child);
    //-------------
    let moduleMap;
    if (child.$exportFun != null) {
      // 設定輸出是 callback
      let fn = child.$exportFun;
      let modules = fn();
      moduleMap = $organizeSettings(importSettings, modules);

    } else if (child.$exportList != null) {
      // 設定輸出是 []
      let exportMap = {};

      child.$exportList.forEach((name) => {
        if (child.$modules[name] == null) {
          throw new Error('...');
        }
        exportMap[name] = child.$modules[name];
      });

      moduleMap = $organizeSettings(importSettings, exportMap);
    }
    //-------------
    this.import(moduleMap);
  }
  //--------------------------------------
  // 當 root 都 import 完
  // 會執行的 callback
  onload(callback) {
    // debugger;
    callback = callback.bind(this);
    this.$onloadList.push(callback);
  }
  //--------------------------------------
  finish() {
    // debugger;
    if (this.$parent == null) {
      // debugger;
      this.$onloaded();
    } else {
      throw new Error('...');
    }
  }
  //--------------------------------------
  $onloaded() {
    // debugger;
    // 由最下層開始
    for (let i = 0; i < this.$onloadList.length; i++) {
      // debugger;
      let fn = this.$onloadList[i];
      fn(this);
    }
    for (let child of this.$childs) {
      // debugger;
      child.$onloaded();
    }
  }
}
const moduleBridge = new ModuleBridge();

////////////////////////////////////////
// name: (string|[]|{})
function $organizeSettings(importSettings, modules) {
  // debugger;

  let $moduleMap = {};

  if (importSettings == null) {
    // import 沒有設限
    if (!isPlainObject(modules)) {
      throw new Error('...');
    }
    Object.assign($moduleMap, modules);

  } else if (typeof(importSettings) == 'string') {
    // export 只有單個模組

    $moduleMap[importSettings] = modules;

  } else if (Array.isArray(importSettings)) {
    // export 多個模組，但不需改名
    importSettings.forEach((name) => {
      if (name in modules) {
        $moduleMap[name] = modules[name];
      }
    });

  } else if (isPlainObject(importSettings)) {
    // export 多個模組
    // import 時有改名稱
    for (let key in importSettings) {
      let newName = importSettings[key];
      if (modules[key] == null) {
        throw new Error('...');
      }
      $moduleMap[newName] = modules[key];
    }
  } else {
    throw new Error('.....');
  }
  return $moduleMap;
}
//-----------------------
function isPlainObject(obj) {
  // debugger;
  let proto;
  let Ctor;
  let res;
  if (typeof obj != 'object') {
    return false;
  }
  // Detect obvious negatives
  // Use toString instead of jQuery.type to catch host objects
  res = proto_toString.call(obj);
  res = reg_1.test(res);

  if (!obj || !res) {
    return false;
  }
  proto = Object.getPrototypeOf(obj);

  // Objects with no prototype (e.g., `Object.create( null )`) are plain
  if (!proto) {
    return true;
  }
  // Objects with prototype are plain iff they were constructed by a global Object function
  Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

  return (typeof Ctor == "function" && Ctor === class2typeCts);
}
//--------------------------------------
export {
  ModuleBridge,
  moduleBridge
};

export default ModuleBridge;
