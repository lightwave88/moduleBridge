debugger;

import {
	ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
	handle as h_a
} from './a.js';

$MB.importHandle('a', h_a);
//-----------------------
// 不同處
import module_b from './b/index.js';
$MB.import('b', module_b);
//-----------------------
// 對外輸出
function handle(outsideMoudule) {

	// 引入外部 outsideMoudule
	$MB.import('outside', outsideMoudule);
	$MB.finish();

	const a = $MB.get('a');
	const b = $MB.get('b');

	return {
		a,
		b
	};
}

export {
	handle
};