import {
  ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
  handle as h_a
} from './a.js';
$MB.importHandle('a', h_a);
//-----------------------
import {
  handle as h_b
} from './b/index.js';
$MB.importHandle('b', h_b);
//-----------------------

$MB.finish();
//-----------------------
// 對外輸出
const a = $MB.get('a');
const b = $MB.get('b');
export default {
  a,
  b
};