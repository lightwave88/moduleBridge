import {
  ModuleBridge,
  moduleBridge
} from './src/moduleBridge.js';

export {
  ModuleBridge,
  moduleBridge
};

export default ModuleBridge;
