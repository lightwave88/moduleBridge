// 用來串聯各個 module
class ModuleBridge {
  $parent = null;
  $modules = new Map();
  //--------------------------------------
  constructor() { }

  get parent() {
    return this.$parent;
  }

  set parent(value) { }
  //--------------------------------------
  // API
  import(name, module = null) {
    // debugger;

    if (module == null && typeof (name) != 'string') {
      let modules = name;
      name = null;
      Object.keys(modules).forEach((moduleName) => {
        // debugger;
        let m = modules[moduleName];
        this.import(moduleName, m);
      });
      return;
    }

    this.$modules.set(name, module);
  }
  //--------------------------------------
  // API
  // 是否要往上層找
  get(name, justSelf = false) {

    let res = null;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    let $this = this;
    while ($this != null) {
      if ($this.$modules.has(name)) {
        res = $this.$modules.get(name);
        break;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return res;
  }
  //--------------------------------------
  // API
  has(name, justSelf = false) {
    let $this = this;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    while ($this != null) {
      if ($this.$modules.has(name)) {
        return true;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return false;
  }
  //--------------------------------------
  link(p) {
    if (!(p instanceof ModuleBridge)) {
      let er = 'moduleBridge.link(parent) parent must instanceof ModuleBridge';
      throw new TypeError(er);
    }
    this.$parent = p;
  }
}
const moduleBridge = new ModuleBridge();

export {
  ModuleBridge,
  moduleBridge
};
