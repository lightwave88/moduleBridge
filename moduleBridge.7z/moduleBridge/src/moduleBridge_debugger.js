const reg_1 = /^\[object Object\]$/;

const proto_toString = Object.prototype.toString;
const class2type = {};
const class2typeCts = {}.constructor;
const hasOwn = class2type.hasOwnProperty;
////////////////////////////////////////
let $UID = 0;

// 用來串聯各個 module
class ModuleBridge {
  $id;
  $parent = null;
  $childs = new Set();

  // 自己區塊的模組
  $modules = {};

  // 自己區塊的延後引入的模組
  $later_import = [];

  // 對外 export handle
  $exportFun;

  $onloadList = [];
  //--------------------------------------
  constructor() {
    this.$id = $UID++;
  }
  //--------------------------------------
  get parent() {
    return this.$parent;
  }
  //--------------------------------------
  set parent(value) {
    if (this.$parent != null) {
      throw new Error('has parent before');
    }
    this.$parent = value;
  }
  //--------------------------------------
  // 知道有那些 modules
  get modules() {
    let $m = {};
    let root = this;

    while (root != null) {
      Object.assign($m, root.$modules);
      root = root.$parent || null;
    }
    return $m;
  }
  //--------------------------------------
  // API
  // import({})
  // import(arg[0], moduleBridge), arg[0]: ([]|string|{})
  // import(name, module)
  import(name, module = null) {

    if (module == null) {

      if (isPlainObject(name)) {
        let modules = name;
        name = null;
        for (let moduleName in modules) {
          this.import(moduleName, modules[moduleName]);
        }
      }
    } else {
      debugger;
      if (module instanceof ModuleBridge) {
        // 另外一個 API
        // ModuleBridge 之間建立連接
        this.importChild(name, module);
        return;
      } else {
        if (name in this.$modules) {
          throw new Error(`name(${name}) conflict`);
        }
        this.$modules[name] = module;
      }
    }
  }
  //--------------------------------------
  // (name, handle, later)
  importHandle(name, handle, later = false) {
    debugger;

    if (later) {
      let item = new ImportLater(this, handle, name);
      this.$later_import.push(item);
    } else {
      let res = handle(this);
      res = $import(name, res);

      this.import(res);
    }
  }
  //--------------------------------------
  // 最重要的地方
  finish() {
    debugger;

    // 先引進自己區塊的模組
    this.$later_import.forEach((item) => {
      debugger;
      let res = item.import();
      debugger;
      this.import(res);
    });
    //------------------
    debugger;
    for (let child of this.$childs) {
      child.finish();
    }
    //------------------
    debugger;
    // 在引用 child 的模組
    for (let child of this.$childs) {
      debugger;
      let fn = child.$exportFun;
      let res = fn();
      res = $import(child.name, res);
      this.import(res);
    }
    //------------------
    // loaded 完要做的事
    while (this.$onloadList.length > 0) {
      debugger;
      let fun = this.$onloadList.shift();
      fun();
    }
  }
  //--------------------------------------
  // API
  // 是否要往上層找
  get(name, justSelf = false) {

    let res = null;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    let $this = this;
    while ($this != null) {
      if (name in $this.$modules) {
        res = $this.$modules[name];
        break;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return res;
  }
  //--------------------------------------
  // API
  has(name, justSelf = false) {
    let $this = this;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    while ($this != null) {
      if (name in $this.$modules) {
        return true;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return false;
  }
  //--------------------------------------
  export(fn) {
    debugger;
    this.$exportFun = fn.bind(this, this);
  }
  //--------------------------------------
  // 傳統用法
  link(parent) {
    if (!(parent instanceof ModuleBridge)) {
      let er = 'moduleBridge.link(parent) parent must instanceof ModuleBridge';
      throw new TypeError(er);
    }
    this.parent = parent;
  }
  //--------------------------------------
  // name: (string|[]|{})
  importChild(name, child) {
    debugger;

    if (!(child instanceof ModuleBridge)) {
      let er = 'moduleBridge.link(parent) parent must instanceof ModuleBridge';
      throw new TypeError(er);
    }
    child.name = name;
    child.parent = this;
    this.$childs.add(child);
    //-------------
    debugger;
    // 轉移 onload 到最外層
    let root = this;

    // 到最外層
    while (root.$parent != null) {
      root = root.$parent;
    }

    while (child.$onloadList.length > 0) {
      debugger;
      let fun = child.$onloadList.shift();
      root.$onloadList.push(fun);
    }
  }
  //--------------------------------------
  onload(callback) {
    let fun = callback.bind(this, this);
    this.$onloadList.push(fun);
  }
}
const moduleBridge = new ModuleBridge();

////////////////////////////////////////
// 輔助類
class ImportLater {
  name;
  callback;
  module;
  //------------------
  constructor(module, callback, name) {
    this.module = module;
    this.callback = callback;
    this.name = name;
  }
  //------------------
  import() {
    let fn = this.callback;
    let res = fn(this.module);
    res = $import(this.name, res);
    return res;
  }
}
//-----------------------
function $import($name, res) {
  debugger;

  let $res = {};

  if (typeof ($name) == 'string') {
    $res[$name] = res;
  } else if (Array.isArray($name)) {

    $name.forEach((name) => {
      if (name in res) {
        $res[name] = res[name];
      }
    });

  } else if (isPlainObject($name)) {

    for (let key in $name) {
      let _name = ($name[key] != null) ? $name[key] : key;
      if (key in res) {
        $res[_name] = res[key];
      }
    }
  } else {
    throw new Error('...');
  }
  return $res;
}
//-----------------------
function isPlainObject(obj) {
  // debugger;
  let proto;
  let Ctor;
  let res;
  if (typeof obj != 'object') {
    return false;
  }
  // Detect obvious negatives
  // Use toString instead of jQuery.type to catch host objects
  res = proto_toString.call(obj);
  res = reg_1.test(res);

  if (!obj || !res) {
    return false;
  }
  proto = Object.getPrototypeOf(obj);

  // Objects with no prototype (e.g., `Object.create( null )`) are plain
  if (!proto) {
    return true;
  }
  // Objects with prototype are plain iff they were constructed by a global Object function
  Ctor = hasOwn.call(proto, "constructor") && proto.constructor;

  return (typeof Ctor == "function" && Ctor === class2typeCts);
}
//--------------------------------------
export {
  ModuleBridge,
  moduleBridge
};