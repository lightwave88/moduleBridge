let $MB;

const $c = {
  name: 'c',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//-------------
function loaded(mb) {
  debugger;
  console.log('c...');
  console.dir(mb.modules());
  console.log('----------');
}
//-------------
function handle(mb) {
  debugger;
  $MB = mb;
  $MB.onload(loaded);
  return $c;
}
//-------------
export {
  handle
};
