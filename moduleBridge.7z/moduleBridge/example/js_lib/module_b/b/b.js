let $MB;

const $b = {
  name: 'b',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};
//-------------
function loaded(mb) {
  debugger;
  console.log('b loaded');
  console.dir(mb.modules());
}
//-------------
function handle(mb) {
  debugger;
  $MB = mb;  
  $MB.onload(loaded);
  return $b;
}
//-------------
export {
  handle
};