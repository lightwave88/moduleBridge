import {
	ModuleBridge
} from '../../moduleBridge.js';
const $MB = new ModuleBridge();
//-----------------------
import {
	handle as h_b
} from './b.js';

// 對外輸出 b
$MB.importHandle('b', h_b);
//-----------------------
import {
	handle as h_c
} from './c.js';

// c 只在此區塊可以看到
$MB.importHandle('c', h_c);
//-----------------------
function handle(mb) {
	debugger;

	// 對外連接
	$MB.link(mb);

	// 對外輸出 b
	const b = $MB.get('b');
	return b;
}

export {
	handle
};