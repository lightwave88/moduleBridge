debugger;

let $MB;

const $c = {
  name: 'c',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    console.dir($MB.modules());
  }
};

function handle(mb) {
  debugger;
  $MB = mb;
	
	// 可以取得外部模組
	const outside = $MB.get('outside');
	$c.outside = outside;
	
  return $c;
}

export {
  handle
};