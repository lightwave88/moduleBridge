debugger;

let $MB;

const $a = {
  name: 'a',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    const b = $MB.get('b');
		const outside = $MB.get('outside');
    console.dir(b);
		console.dir(outside);
  }
};

function handle(mb) {
  debugger;
  $MB = mb;
	
	// 可以取得外部模組
	const outside = $MB.get('outside');
	$a.outside = 	outside;
  return $a;
}

export {
  handle
};