debugger;

let $MB;

const $a = {
  name: 'a',
  aboutMe() {
    debugger;
    console.log(this.name);

    this.getModules();
  },
  getModules() {
    debugger;
    const b = $MB.get('b');
		const outside = $MB.get('outside');
    console.dir(b);
		console.dir(outside);
  }
};
//------------------
function loaded() {
  debugger;
  // 可以取得外部模組
  console.log('a...');
  const outside = this.get('outside');
	$a.outside = 	outside;
  console.dir(this.modules());
  console.log('----------');
}
//------------------
function handle(mb) {
  debugger;
  $MB = mb;

  this.onload(loaded);

  return $a;
}

export {
  handle
};
