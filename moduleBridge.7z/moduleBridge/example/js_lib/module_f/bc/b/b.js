debugger;

let $MB;

const $b = {
	name: 'b',
	aboutMe() {
		debugger;
		console.log(this.name);

		this.getModules();
	},
	getModules() {
		debugger;
		console.dir($MB.modules());
	}
};

function handle(mb) {
	debugger;
	$MB = mb;
	return $b;
}

export {
	handle
};