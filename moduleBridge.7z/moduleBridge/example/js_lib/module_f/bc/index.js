import {
	ModuleBridge
} from '../../moduleBridge.js';
const $MB = new ModuleBridge();
//------------------
import m_b from './b/index.js';
$MB.import('b', m_b);
//------------------
import {
	handle as h_c
} from './c/index.js';
$MB.importHandle('c', h_c);
//------------------

function onloaded(mb) {
	debugger;
	console.dir(mb.modules());
	console.dir(mb.modules(true));
}

$MB.export(function(mb) {
	debugger;
	const b = mb.get('b');
	const c = mb.get('c');
	
	mb.onload(onloaded);
	return {
		b,
		c
	}
});

export default $MB;